package com.equifax.intlps.ic.solution.es.component.datasource.informa.request.cxf;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para getTablesResponseType complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="getTablesResponseType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ok" type="{http://www.w3.org/2001/XMLSchema}boolean"/&gt;
 *         &lt;element name="versionCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="tablasInformacionComercial" type="{http://www.w3.org/2001/XMLSchema}anyType"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getTablesResponseType", propOrder = {
    "ok",
    "versionCode",
    "tablasInformacionComercial"
})
public class GetTablesResponseType {

    protected boolean ok;
    @XmlElement(required = true, nillable = true)
    protected String versionCode;
    @XmlElement(required = true, nillable = true)
    protected Object tablasInformacionComercial;

    /**
     * Obtiene el valor de la propiedad ok.
     * 
     */
    public boolean isOk() {
        return ok;
    }

    /**
     * Define el valor de la propiedad ok.
     * 
     */
    public void setOk(boolean value) {
        this.ok = value;
    }

    /**
     * Obtiene el valor de la propiedad versionCode.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVersionCode() {
        return versionCode;
    }

    /**
     * Define el valor de la propiedad versionCode.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVersionCode(String value) {
        this.versionCode = value;
    }

    /**
     * Obtiene el valor de la propiedad tablasInformacionComercial.
     * 
     * @return
     *     possible object is
     *     {@link Object }
     *     
     */
    public Object getTablasInformacionComercial() {
        return tablasInformacionComercial;
    }

    /**
     * Define el valor de la propiedad tablasInformacionComercial.
     * 
     * @param value
     *     allowed object is
     *     {@link Object }
     *     
     */
    public void setTablasInformacionComercial(Object value) {
        this.tablasInformacionComercial = value;
    }

}
