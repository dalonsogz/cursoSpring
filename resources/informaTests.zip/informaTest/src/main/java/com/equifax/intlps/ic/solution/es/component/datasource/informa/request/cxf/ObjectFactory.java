package com.equifax.intlps.ic.solution.es.component.datasource.informa.request.cxf;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the es.informa.services.si.gps package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetProduct_QNAME = new QName("http://services.informa.es/si/gps", "getProduct");
    private final static QName _GetProductResponse_QNAME = new QName("http://services.informa.es/si/gps", "getProductResponse");
    private final static QName _GetTables_QNAME = new QName("http://services.informa.es/si/gps", "getTables");
    private final static QName _GetTablesResponse_QNAME = new QName("http://services.informa.es/si/gps", "getTablesResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: es.informa.services.si.gps
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetProductType }
     * 
     */
    public GetProductType createGetProductType() {
        return new GetProductType();
    }

    /**
     * Create an instance of {@link GetProductResponseType }
     * 
     */
    public GetProductResponseType createGetProductResponseType() {
        return new GetProductResponseType();
    }

    /**
     * Create an instance of {@link GetTablesType }
     * 
     */
    public GetTablesType createGetTablesType() {
        return new GetTablesType();
    }

    /**
     * Create an instance of {@link GetTablesResponseType }
     * 
     */
    public GetTablesResponseType createGetTablesResponseType() {
        return new GetTablesResponseType();
    }

    /**
     * Create an instance of {@link ParametersType }
     * 
     */
    public ParametersType createParametersType() {
        return new ParametersType();
    }

    /**
     * Create an instance of {@link ParameterType }
     * 
     */
    public ParameterType createParameterType() {
        return new ParameterType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetProductType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.informa.es/si/gps", name = "getProduct")
    public JAXBElement<GetProductType> createGetProduct(GetProductType value) {
        return new JAXBElement<GetProductType>(_GetProduct_QNAME, GetProductType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetProductResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.informa.es/si/gps", name = "getProductResponse")
    public JAXBElement<GetProductResponseType> createGetProductResponse(GetProductResponseType value) {
        return new JAXBElement<GetProductResponseType>(_GetProductResponse_QNAME, GetProductResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTablesType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.informa.es/si/gps", name = "getTables")
    public JAXBElement<GetTablesType> createGetTables(GetTablesType value) {
        return new JAXBElement<GetTablesType>(_GetTables_QNAME, GetTablesType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTablesResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://services.informa.es/si/gps", name = "getTablesResponse")
    public JAXBElement<GetTablesResponseType> createGetTablesResponse(GetTablesResponseType value) {
        return new JAXBElement<GetTablesResponseType>(_GetTablesResponse_QNAME, GetTablesResponseType.class, null, value);
    }

}
