package com.equifax.ic.international.datasources.spain.informa.schema.beans;

import java.io.Serializable;
import java.util.ArrayList;

public class NormInformaResponse implements Serializable {

	private static final long serialVersionUID = -7576084493626984456L;

//    private String transactionid;

	private String capitalSocial;
	private String nota;
	private String codigo;
	private String status;
	private String fechaConstitucion;
	private String totalAdministradores;
	private String mediaDiasDemora;
	private String empleados;
	private String fechaBalanceDisponibleInforma;
	private String anoBalance;
	private ArrayList<Balance> balances;
	
    private Error error;

	
	public NormInformaResponse() {
		super();
	}
	
	public String getCapitalSocial() {
		return capitalSocial;
	}
	public void setCapitalSocial(String capitalSocial) {
		this.capitalSocial = capitalSocial;
	}
	public String getNota() {
		return nota;
	}
	public void setNota(String nota) {
		this.nota = nota;
	}
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getFechaConstitucion() {
		return fechaConstitucion;
	}
	public void setFechaConstitucion(String fechaConstitucion) {
		this.fechaConstitucion = fechaConstitucion;
	}
	public String getTotalAdministradores() {
		return totalAdministradores;
	}
	public void setTotalAdministradores(String totalAdministradores) {
		this.totalAdministradores = totalAdministradores;
	}
	public String getMediaDiasDemora() {
		return mediaDiasDemora;
	}
	public void setMediaDiasDemora(String mediaDiasDemora) {
		this.mediaDiasDemora = mediaDiasDemora;
	}
	public String getEmpleados() {
		return empleados;
	}
	public void setEmpleados(String empleados) {
		this.empleados = empleados;
	}
	public String getFechaBalanceDisponibleInforma() {
		return fechaBalanceDisponibleInforma;
	}
	public void setFechaBalanceDisponibleInforma(String fechaBalanceDisponibleInforma) {
		this.fechaBalanceDisponibleInforma = fechaBalanceDisponibleInforma;
	}
	public String getAnoBalance() {
		return anoBalance;
	}
	public void setAnoBalance(String anoBalance) {
		this.anoBalance = anoBalance;
	}
	public ArrayList<Balance> getBalances() {
		return balances;
	}
	public void setBalances(ArrayList<Balance> balances) {
		this.balances = balances;
	}
	public Error getError() {
		return error;
	}
	public void setError(Error error) {
		this.error = error;
	}
//	public String getTransactionid() {
//		return transactionid;
//	}
//	public void setTransactionid(String transactionid) {
//		this.transactionid = transactionid;
//	}

	/**
	 * Metodo para rellenar o crear un nuevo obeto de respuesto con datos de prueba
	 * @param response objeto de respuesta a rellenar
	 * @return la respuesta rellena con datos de prueba o un objeto NormInformaResponse
	 * 			nuevo relleno con datos de prueba si response era null
	 */
    public static NormInformaResponse fillTestData(NormInformaResponse response) {

 		Balance balanceOut0 = new Balance();
 		balanceOut0.setAno("0");
 		balanceOut0.setActivoNoCorriente("NO");
 		balanceOut0.setActivoCorriente("NO");
 		balanceOut0.setPatrimonioNeto("100");
 		balanceOut0.setPasivoNoCorriente("101");
 		balanceOut0.setPasivoCorriente("102");
 		balanceOut0.setCifraNegocioFact("103");
 		balanceOut0.setMargen("50");
 		balanceOut0.setEbitda("10");
 		balanceOut0.setAmortInmov("11");
 		balanceOut0.setEbit("12");
 		balanceOut0.setRtdoFinanciero("20");
 		balanceOut0.setGastosFinancieros("21");
 		balanceOut0.setResultadoNeto("22");
 		balanceOut0.setFondoManiobra("30");
 		balanceOut0.setPdoMedioCobroDias("31");
 		balanceOut0.setPdoMedioPagoDias("32");
 		balanceOut0.setLiquidezInmediataPorc("40");
 		balanceOut0.setEndeudamientoPorc("41");
 		balanceOut0.setCapitalSocial("42");
 		balanceOut0.setPuntoFlashIncidenc("43");
 		Balance balanceOut1 = new Balance();
 		balanceOut1.setAno("1");
 		balanceOut1.setActivoNoCorriente("SI");
 		balanceOut1.setActivoCorriente("NO");
 		balanceOut1.setPatrimonioNeto("200");
 		balanceOut1.setPasivoNoCorriente("201");
 		balanceOut1.setPasivoCorriente("202");
 		balanceOut1.setCifraNegocioFact("103");
 		balanceOut1.setMargen("25");
 		balanceOut1.setEbitda("14");
 		balanceOut1.setAmortInmov("15");
 		balanceOut1.setEbit("16");
 		balanceOut1.setRtdoFinanciero("24");
 		balanceOut1.setGastosFinancieros("25");
 		balanceOut1.setResultadoNeto("26");
 		balanceOut1.setFondoManiobra("34");
 		balanceOut1.setPdoMedioCobroDias("35");
 		balanceOut1.setPdoMedioPagoDias("36");
 		balanceOut1.setLiquidezInmediataPorc("44");
 		balanceOut1.setEndeudamientoPorc("45");
 		balanceOut1.setCapitalSocial("46");
 		balanceOut1.setPuntoFlashIncidenc("47");
 		Balance balanceOut2 = new Balance();
 		balanceOut2.setAno("2");
 		balanceOut2.setActivoNoCorriente("NO");
 		balanceOut2.setActivoCorriente("SI");
 		balanceOut2.setPatrimonioNeto("300");
 		balanceOut2.setPasivoNoCorriente("301");
 		balanceOut2.setPasivoCorriente("302");
 		balanceOut2.setCifraNegocioFact("303");
 		balanceOut2.setMargen("75");
 		balanceOut2.setEbitda("17");
 		balanceOut2.setAmortInmov("18");
 		balanceOut2.setEbit("19");
 		balanceOut2.setRtdoFinanciero("27");
 		balanceOut2.setGastosFinancieros("28");
 		balanceOut2.setResultadoNeto("29");
 		balanceOut2.setFondoManiobra("37");
 		balanceOut2.setPdoMedioCobroDias("38");
 		balanceOut2.setPdoMedioPagoDias("39");
 		balanceOut2.setLiquidezInmediataPorc("47");
 		balanceOut2.setEndeudamientoPorc("48");
 		balanceOut2.setCapitalSocial("49");
 		balanceOut2.setPuntoFlashIncidenc("46");

 		ArrayList<Balance> balances = new ArrayList<Balance>();
 		balances.add(balanceOut0);
 		balances.add(balanceOut1);
 		balances.add(balanceOut2);

 		if (response==null)
 			response = new NormInformaResponse();
 		response.setCapitalSocial("2000");
 		response.setNota("45");
 		response.setCodigo("65754");
 		response.setStatus("1");
 		response.setFechaConstitucion("01152018");
 		response.setTotalAdministradores("5");
 		response.setMediaDiasDemora("10");
 		response.setEmpleados("125");
 		response.setFechaBalanceDisponibleInforma("01052018");
 		response.setAnoBalance("2018");
 		response.setBalances(balances);

 		return response;
 	}


}
