package com.equifax.ic.international.datasources.spain.informa.schema.beans;

import java.io.Serializable;

public class Balance implements Serializable {

	private static final long serialVersionUID = -2774824803811070241L;
	
	private String ano;
	private String activoNoCorriente;
	private String activoCorriente;
	private String patrimonioNeto;
	private String pasivoNoCorriente;
	private String pasivoCorriente;
	private String cifraNegocioFact;
	private String margen;
	private String ebitda;
	private String amortInmov;
	private String ebit;
	private String rtdoFinanciero;
	private String gastosFinancieros;
	private String resultadoNeto;
	private String fondoManiobra;
	private String pdoMedioCobroDias;
	private String pdoMedioPagoDias;
	private String liquidezInmediataPorc;
	private String endeudamientoPorc;
	private String capitalSocial;
	private String puntoFlashIncidenc;

	public Balance() {
		super();
	}

	public String getAno() {
		return ano;
	}

	public void setAno(String ano) {
		this.ano = ano;
	}

	public String getActivoNoCorriente() {
		return activoNoCorriente;
	}

	public void setActivoNoCorriente(String activoNoCorriente) {
		this.activoNoCorriente = activoNoCorriente;
	}

	public String getActivoCorriente() {
		return activoCorriente;
	}

	public void setActivoCorriente(String activoCorriente) {
		this.activoCorriente = activoCorriente;
	}

	public String getPatrimonioNeto() {
		return patrimonioNeto;
	}

	public void setPatrimonioNeto(String patrimonioNeto) {
		this.patrimonioNeto = patrimonioNeto;
	}

	public String getPasivoNoCorriente() {
		return pasivoNoCorriente;
	}

	public void setPasivoNoCorriente(String pasivoNoCorriente) {
		this.pasivoNoCorriente = pasivoNoCorriente;
	}

	public String getPasivoCorriente() {
		return pasivoCorriente;
	}

	public void setPasivoCorriente(String pasivoCorriente) {
		this.pasivoCorriente = pasivoCorriente;
	}

	public String getCifraNegocioFact() {
		return cifraNegocioFact;
	}

	public void setCifraNegocioFact(String cifraNegocioFact) {
		this.cifraNegocioFact = cifraNegocioFact;
	}

	public String getMargen() {
		return margen;
	}

	public void setMargen(String margen) {
		this.margen = margen;
	}

	public String getEbitda() {
		return ebitda;
	}

	public void setEbitda(String ebitda) {
		this.ebitda = ebitda;
	}

	public String getAmortInmov() {
		return amortInmov;
	}

	public void setAmortInmov(String amortInmov) {
		this.amortInmov = amortInmov;
	}

	public String getEbit() {
		return ebit;
	}

	public void setEbit(String ebit) {
		this.ebit = ebit;
	}

	public String getRtdoFinanciero() {
		return rtdoFinanciero;
	}

	public void setRtdoFinanciero(String rtdoFinanciero) {
		this.rtdoFinanciero = rtdoFinanciero;
	}

	public String getGastosFinancieros() {
		return gastosFinancieros;
	}

	public void setGastosFinancieros(String gastosFinancieros) {
		this.gastosFinancieros = gastosFinancieros;
	}

	public String getResultadoNeto() {
		return resultadoNeto;
	}

	public void setResultadoNeto(String resultadoNeto) {
		this.resultadoNeto = resultadoNeto;
	}

	public String getFondoManiobra() {
		return fondoManiobra;
	}

	public void setFondoManiobra(String fondoManiobra) {
		this.fondoManiobra = fondoManiobra;
	}

	public String getPdoMedioCobroDias() {
		return pdoMedioCobroDias;
	}

	public void setPdoMedioCobroDias(String pdoMedioCobroDias) {
		this.pdoMedioCobroDias = pdoMedioCobroDias;
	}

	public String getPdoMedioPagoDias() {
		return pdoMedioPagoDias;
	}

	public void setPdoMedioPagoDias(String pdoMedioPagoDias) {
		this.pdoMedioPagoDias = pdoMedioPagoDias;
	}

	public String getLiquidezInmediataPorc() {
		return liquidezInmediataPorc;
	}

	public void setLiquidezInmediataPorc(String liquidezInmediataPorc) {
		this.liquidezInmediataPorc = liquidezInmediataPorc;
	}

	public String getEndeudamientoPorc() {
		return endeudamientoPorc;
	}

	public void setEndeudamientoPorc(String endeudamientoPorc) {
		this.endeudamientoPorc = endeudamientoPorc;
	}

	public String getCapitalSocial() {
		return capitalSocial;
	}

	public void setCapitalSocial(String capitalSocial) {
		this.capitalSocial = capitalSocial;
	}

	public String getPuntoFlashIncidenc() {
		return puntoFlashIncidenc;
	}

	public void setPuntoFlashIncidenc(String puntoFlashIncidenc) {
		this.puntoFlashIncidenc = puntoFlashIncidenc;
	}

}
