@javax.xml.bind.annotation.XmlSchema(namespace = "http://services.informa.es/si/gps")
package com.equifax.intlps.ic.solution.es.component.datasource.informa.request.cxf;
