package com.equifax.intlps.ic.solution.es.component.datasource.informa.request;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.namespace.QName;

import com.equifax.intlps.ic.solution.es.component.datasource.informa.request.cxf.GetProduct;
import com.equifax.intlps.ic.solution.es.component.datasource.informa.request.cxf.GetProductImplService;
import com.equifax.intlps.ic.solution.es.component.datasource.informa.request.cxf.GetProductResponseType;
import com.equifax.intlps.ic.solution.es.component.datasource.informa.request.cxf.GetProductType;
import com.equifax.intlps.ic.solution.es.component.datasource.informa.request.cxf.ParametersType;
import com.equifax.intlps.ic.solution.es.component.datasource.informa.request.cxf.ParameterType;
 
public final class CxfClientTest {
 
  private final String WSDL_SOURCE = "https://services.informa.es/soap/gps?wsdl";
	
  private static final QName SERVICE_NAME = 
		  new QName("http://services.informa.es/si/gps", "GetProductImplService");
 
  private CxfClientTest(String args[])
  {
	  try {
			String wsdlFileName = null;
		    if (args.length == 0)
		    {
		    	wsdlFileName = "informa_gps.wsdl";
	//	      System.out.println("please specify wsdl");
	//	      System.exit(1);
		    } else {
		    	wsdlFileName = args[0];
		    }
		 
		    URL wsdlURL;
			//Get file from resources folder
			ClassLoader classLoader = getClass().getClassLoader();
		    File wsdlFile = new File(classLoader.getResource(wsdlFileName).getFile());
		    if (!wsdlFile.exists())
		    {
		    	throw new Exception("WSDL file not exists!!");
		    }
		 
		      wsdlURL = wsdlFile.toURL();
		    System.out.println(wsdlURL);
		    GetProductImplService ss = new GetProductImplService(wsdlURL, SERVICE_NAME);
		    GetProduct port = ss.getGetProductPort();
		 
		    GetProductType getProductType = new GetProductType();
		    getProductType.setUserId("597750");
		    getProductType.setPassword("88FIAT");
		    getProductType.setProductCode("INFORME_MAYOR");
		    getProductType.setProductVersion("1.2");
		    List<ParameterType> parameters = new ArrayList<ParameterType>();
		    ParametersType parametersType = new ParametersType();
		    ParameterType param1=new ParameterType();param1.setName("CIF");param1.setValue("A80192727");
		    ParameterType param2=new ParameterType();param2.setName("NORMALIZADO");param2.setValue("1");
		    ParameterType param3=new ParameterType();param2.setName("FORMATO_PGC");param3.setValue("1");
		    parametersType.getParameter().add(param1);
		    parametersType.getParameter().add(param2);
		    parametersType.getParameter().add(param3);
		    System.out.println("Invoking getProduct...");
		    GetProductResponseType getProductResponseType = port.getProduct(getProductType);
		    System.out.println("Server responded with: " + getProductResponseType.toString());
		    System.out.println();
		 
		    System.exit(0);
	  } catch (Exception e) {
		  e.printStackTrace();
	  }
		    
  }
 
  public static void main(String args[]) throws Exception
  {
	  new CxfClientTest(args);
  }
}
