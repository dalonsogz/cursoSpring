package com.equifax.intlps.ic.solution.es.component.datasource.informa.request;


import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

//import com.sun.jersey.api.client.Client;
//import com.sun.jersey.api.client.ClientResponse;
//import com.sun.jersey.api.client.WebResource;
//import com.sun.jersey.api.client.config.ClientConfig;
//import com.sun.jersey.api.client.config.DefaultClientConfig;
//import com.sun.jersey.api.client.filter.LoggingFilter;

public class RESTyClient {
    public static void main(String[] args) throws Exception {
/*    	
        ClientConfig config = new DefaultClientConfig();
        config.getClasses().add(SoapProvider.class);
        Client c = Client.create(config);
        c.addFilter(new LoggingFilter());
 
        MessageFactory messageFactory = MessageFactory.newInstance();
        SOAPMessage message = messageFactory.createMessage();
        SOAPPart soapPart = message.getSOAPPart();
        SOAPEnvelope env = soapPart.getEnvelope();
        env.addNamespaceDeclaration("gps", "http://services.informa.es/si/gps");
        SOAPBody bodyElement = env.getBody();
        SOAPElement getProductElement = bodyElement.addChildElement("gps:getProduct");
        SOAPElement userIdElement = getProductElement.addChildElement("userId").addTextNode("597750");
        SOAPElement passwordElement = getProductElement.addChildElement("password").addTextNode("88FIAT");
        SOAPElement productCodeElement = getProductElement.addChildElement("productCode").addTextNode("INFORME_MAYOR");
        SOAPElement productVersionElement = getProductElement.addChildElement("productVersion").addTextNode("1.2");
        SOAPElement parametersElement = getProductElement.addChildElement("parameters");
        SOAPElement cif = parametersElement.addChildElement("parameter").addAttribute(env.createName("name"), "CIF").addTextNode("A80192727");
        SOAPElement normalizado = parametersElement.addChildElement("parameter").addAttribute(env.createName("name"), "NORMALIZADO").addTextNode("1");
        SOAPElement formatopPgc = parametersElement.addChildElement("parameter").addAttribute(env.createName("name"), "FORMATO_PGC").addTextNode("1");

        message.saveChanges();
 
        WebResource service = c.resource("https://services.informa.es/soap/gps/");
        service.header("Accept-Encoding","gzip,deflate");
   		service.header("Content-Type:","text/xml;charset=UTF-8");
   		service.header("SOAPAction","");
// 		service.header("SOAPAction","\"https://services.informa.es/soap/gps/getProduct\"");
//		service.header("Content-Length","723");
		service.header("Host","services.informa.es");
		service.header("Connection","Keep-Alive");
		service.header("User-Agent","Apache-HttpClient/4.1.1 (java 1.5)");
        
		// POST the request
//      ClientResponse cr = service.header("SOAPAction", "\"https://services.informa.es/soap/gps\"").post(ClientResponse.class, message);
        ClientResponse cr = service.post(ClientResponse.class, message);
        message = cr.getEntity(SOAPMessage.class);
 
//        JAXBContext ctx = JAXBContext.newInstance(GetCityWeatherByZIPResponse.class);
//        Unmarshaller um = ctx.createUnmarshaller();
//        GetCityWeatherByZIPResponse response = (um.unmarshal(message.getSOAPPart().getEnvelope().getBody().extractContentAsDocument(), GetCityWeatherByZIPResponse.class)).getValue();
//        System.out.println("City : " + response.getGetCityWeatherByZIPResult().getCity());
//        System.out.println("Temperature : " + response.getGetCityWeatherByZIPResult().getTemperature());
        
        System.out.println("Message : " + message);
*/
    }
}
