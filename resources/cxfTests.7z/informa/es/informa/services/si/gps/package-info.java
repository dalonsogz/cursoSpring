@javax.xml.bind.annotation.XmlSchema(namespace = "http://services.informa.es/si/gps")
package es.informa.services.si.gps;
